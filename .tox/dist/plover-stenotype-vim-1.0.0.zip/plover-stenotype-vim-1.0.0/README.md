# Stenotype Extended vim

Plover plugin for an extended Stenotype layout for one stroke vim

<!-- ![Layout image](https://github.com/sammdot/plover-stenotype-extended/blob/main/screenshot.png) -->
